#include "stm32l4xx.h"
#include "main.h"
void UnInterruptable(void);
void CustomWhile(void);